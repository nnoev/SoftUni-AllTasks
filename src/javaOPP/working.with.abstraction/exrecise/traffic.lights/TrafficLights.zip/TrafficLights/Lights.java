package JavaOOP.WorkingWithAbstractionExrecise.TrafficLights;

public enum Lights {
    RED,
    GREEN,
    YELLOW;
}
