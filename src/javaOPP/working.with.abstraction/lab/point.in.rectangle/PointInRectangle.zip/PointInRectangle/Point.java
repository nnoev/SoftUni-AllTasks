package JavaOOP.WorkingWithAbstractionLab.PointInRectangle;

public class Point {
        int cordinatesX;
        int cordinatesY;

    public Point(int cordinatesX, int cordinatesY) {
        this.cordinatesX = cordinatesX;
        this.cordinatesY = cordinatesY;
    }

    public int getCordinatesX() {
        return cordinatesX;
    }

    public int getCordinatesY() {
        return cordinatesY;
    }

}

