package RandomArrayList;

public class Main {
    public static void main(String[] args) {
        RandomArrayList<String> randomArrayList = new RandomArrayList<String>();
        randomArrayList.getRandomElement();
    }
}
