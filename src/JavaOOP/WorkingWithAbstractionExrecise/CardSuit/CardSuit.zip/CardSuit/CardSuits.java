package JavaOOP.WorkingWithAbstractionExrecise.CardSuit;

public enum CardSuits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES,
}
